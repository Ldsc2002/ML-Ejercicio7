def addOne(number):
    return number + 1